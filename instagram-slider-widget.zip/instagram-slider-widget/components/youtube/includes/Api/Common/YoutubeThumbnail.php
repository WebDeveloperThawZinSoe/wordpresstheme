<?php


namespace YoutubeFeed\Api\Common;

/**
 * Class YoutubeThumbnail
 *
 * @property string $url
 * @property int $width
 * @property int $height
 *
 * @package YoutubeFeed\includes\Api
 */
class YoutubeThumbnail
{

}