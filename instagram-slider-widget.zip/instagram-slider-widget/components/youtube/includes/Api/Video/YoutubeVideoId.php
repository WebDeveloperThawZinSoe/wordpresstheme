<?php


namespace YoutubeFeed\Api\Video;

/**
 * Class YoutubeVideoId
 *
 * @property string $kind
 * @property string $videoId
 *
 * @package YoutubeFeed\includes\Api
 */
class YoutubeVideoId
{

}