(function ($) {

    $(document).ready(function ($) {

    }); // Document Ready

})(jQuery);
