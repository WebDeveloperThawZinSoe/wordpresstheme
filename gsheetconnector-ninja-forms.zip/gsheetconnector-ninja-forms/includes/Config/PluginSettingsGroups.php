<?php if ( ! defined( 'ABSPATH' ) ) exit;

return apply_filters( 'nf_njgs_plugin_settings_groups', array(

    'njgs' => array(
        'id' => 'njgs',
		'label' => __( 'njgs Settings', 'ninja-forms-njgs' ),
    ),

));
