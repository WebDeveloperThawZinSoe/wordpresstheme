<div class="gs-sidebar-block">
				<div class="card1">
					<div class="WP-fields demo-block">
						<h2><span><?php echo __('GSheetConnector Ninja Forms Demo Information', 'gsheetconnector-njforms'); ?></span></h2>
						<p>
						  <label><?php echo __('URL', 'gsheetconnector-njforms'); ?></label>
                    <a href="https://ninjagsheets.gsheetconnector.com/" target="_blank" class="link-supp">https://ninjagsheets.gsheetconnector.com/</a>
						</p>
						<p>
						  <label><?php echo __('Sheet URL', 'gsheetconnector-njforms'); ?></label>
						  <a href="https://docs.google.com/spreadsheets/d/1ooBdX0cgtk155ww9MmdMTw8kDavIy5J1m76VwSrcTSs/edit#gid=1602937341" target="_blank" rel="noopener" class="link-supp"><?php echo __('Demo URL', 'gsheetconnector-njforms'); ?> </a>
						</p>
					 </div>
				 </div>
</div>