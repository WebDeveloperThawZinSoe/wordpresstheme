/*  Demo custom js file */

console.log('RoboGallery :: Demo custom js file');