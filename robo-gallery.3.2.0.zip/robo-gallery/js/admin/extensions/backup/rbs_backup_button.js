/*
*      Robo Gallery     
*      Version: 1.0
*      By Robosoft
*
*      Contact: https://robosoft.co/robogallery/ 
*      Created: 2015
*      Licensed under the GPLv2 license - http://opensource.org/licenses/gpl-2.0.php
*
*      Copyright (c) 2014-2019, Robosoft. All rights reserved.
*      Available only in  https://robosoft.co/robogallery/ 
*/

jQuery(document).ready( function($){
    //var rbsButtonBackup = 
    jQuery(".wp-admin.edit-php.post-type-robo_gallery_table .wrap h1 ~ .page-title-action:last").after("<a href='edit.php?post_type=robo_gallery_table&page=robo-gallery-backup' id='rbs_backup_button' class='page-title-action'>Backup Gallery</a>");
});