<div id="roboGalleryThemeTypeDiv"> 
	<img class="type-logo" src="<?php echo ROBO_GALLERY_URL; ?>app/extensions/galleryType/build/grids/mosaic_active.svg" style="width: 100px; height: 100px;" />
	<h4><?php _e( "Gallery Mosaic", 'robo-gallery'); ?></h4>
	<p>
		<?php _e( "Type", 'robo-gallery'); ?>: <?php echo rbsGalleryUtils::getFullSourceGallery(); ?>
	</p>
</div>

