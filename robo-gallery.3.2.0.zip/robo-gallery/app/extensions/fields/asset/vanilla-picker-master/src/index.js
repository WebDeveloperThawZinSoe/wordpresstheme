import Picker from './js/picker.js';

export default Picker;