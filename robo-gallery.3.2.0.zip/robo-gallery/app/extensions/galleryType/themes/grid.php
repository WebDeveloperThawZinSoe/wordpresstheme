<?php

return array(
	'grid-1' =>  include  ROBO_GALLERY_APP_EXTENSIONS_PATH.'galleryType/themes/grid_1.php',
);