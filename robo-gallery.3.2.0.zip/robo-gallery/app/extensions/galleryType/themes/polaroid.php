<?php

return array(
	'polaroid-1' => include  ROBO_GALLERY_APP_EXTENSIONS_PATH.'galleryType/themes/polaroid_1.php',
);