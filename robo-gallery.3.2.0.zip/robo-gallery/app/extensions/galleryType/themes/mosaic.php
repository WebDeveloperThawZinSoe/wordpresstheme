<?php

return array(
	'mosaic-1' => include  ROBO_GALLERY_APP_EXTENSIONS_PATH.'galleryType/themes/mosaic_1.php',
);