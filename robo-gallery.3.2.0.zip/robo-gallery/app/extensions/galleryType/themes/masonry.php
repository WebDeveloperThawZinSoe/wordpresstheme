<?php

return array(
	'masonry-1' =>  include  ROBO_GALLERY_APP_EXTENSIONS_PATH.'galleryType/themes/masonry_1.php',
);