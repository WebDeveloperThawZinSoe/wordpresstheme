<?php

return array(
	'youtube-1' => include  ROBO_GALLERY_APP_EXTENSIONS_PATH.'galleryType/themes/youtube_1.php',
);