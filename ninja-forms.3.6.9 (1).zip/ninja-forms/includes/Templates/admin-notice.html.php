<div class="<?php echo esc_attr( $class ); ?>">
    <p><?php echo $message; ?></p>
</div>
