<?php get_header(); ?>
<?php include( __DIR__ . '/body.php' ); ?>
<?php get_footer(); ?>
