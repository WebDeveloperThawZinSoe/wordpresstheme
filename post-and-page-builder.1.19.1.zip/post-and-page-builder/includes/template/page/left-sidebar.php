<?php
$sidebar_location = 'sidebar-left';
include( __DIR__ . '/base.php' );
