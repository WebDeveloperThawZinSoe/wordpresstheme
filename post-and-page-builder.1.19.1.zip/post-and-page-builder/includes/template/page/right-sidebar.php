<?php
$sidebar_location = 'sidebar-right';
include( __DIR__ . '/base.php' );
