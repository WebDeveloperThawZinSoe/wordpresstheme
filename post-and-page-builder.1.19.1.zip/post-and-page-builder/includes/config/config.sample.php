<?php
/**
 * Copy this sample file to config.local.php and update it with any variables that you would like to override
 */
/* @formatter:off */
return array (
	'asset_server'   => 'https://wp-assets-dev.boldgrid.com',
);
/* @formatter:on */
