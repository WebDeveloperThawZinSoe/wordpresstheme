import { Page } from './view/gutenberg/page.js';
new Page().init();
