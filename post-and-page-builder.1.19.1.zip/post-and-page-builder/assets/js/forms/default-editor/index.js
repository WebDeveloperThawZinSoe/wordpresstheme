export { Form as DefaultEditor } from './form';
