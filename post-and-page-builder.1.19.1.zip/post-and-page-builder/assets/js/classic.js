import '../scss/_material-reset.scss';
import { Page } from './view/classic';

new Page().init();
