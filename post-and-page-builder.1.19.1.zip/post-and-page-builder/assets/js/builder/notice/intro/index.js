export { Notice as Intro } from './notice';
