import { EditorSelect } from '../../forms/editor-select';

export class Page {
	init() {
		new EditorSelect().init();
	}
}
