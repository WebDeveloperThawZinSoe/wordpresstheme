export { Page } from './page';
