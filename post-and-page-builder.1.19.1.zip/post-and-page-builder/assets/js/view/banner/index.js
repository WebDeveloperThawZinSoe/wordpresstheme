export { Template as Banner } from './template.js';
