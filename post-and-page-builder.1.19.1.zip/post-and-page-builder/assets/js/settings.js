import '../scss/_material-reset.scss';

import { Page } from './view/settings';
new Page().init();
