<script type="text/html" id="tmpl-editor-boldgrid-not-found">
<div class="wpview-error">
	<div class="dashicons dashicons-index-card"></div><p>Form not found.</p>
</div>
</script>
