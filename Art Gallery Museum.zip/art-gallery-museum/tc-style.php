<?php 
	$art_gallery_museum_custom_css ='';

	/*----------------Width Layout -------------------*/
	$art_gallery_museum_theme_lay = get_theme_mod( 'art_gallery_museum_width_options','Full Layout');
    if($art_gallery_museum_theme_lay == 'Full Layout'){
		$art_gallery_museum_custom_css .='body{';
			$art_gallery_museum_custom_css .='max-width: 100%;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_theme_lay == 'Contained Layout'){
		$art_gallery_museum_custom_css .='body{';
			$art_gallery_museum_custom_css .='width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_theme_lay == 'Boxed Layout'){
		$art_gallery_museum_custom_css .='body{';
			$art_gallery_museum_custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;';
		$art_gallery_museum_custom_css .='}';
	}

	/*------ Button Style -------*/
	$art_gallery_museum_top_buttom_padding = get_theme_mod('art_gallery_museum_top_button_padding');
	$art_gallery_museum_left_right_padding = get_theme_mod('art_gallery_museum_left_button_padding');
	if($art_gallery_museum_top_buttom_padding != false || $art_gallery_museum_left_right_padding != false ){
		$art_gallery_museum_custom_css .='.read-btn a.blogbutton-small, #comments input[type="submit"].submit{';
			$art_gallery_museum_custom_css .='padding-top: '.esc_attr($art_gallery_museum_top_buttom_padding).'px; padding-bottom: '.esc_attr($art_gallery_museum_top_buttom_padding).'px; padding-left: '.esc_attr($art_gallery_museum_left_right_padding).'px; padding-right: '.esc_attr($art_gallery_museum_left_right_padding).'px;';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_button_border_radius = get_theme_mod('art_gallery_museum_button_border_radius');
	$art_gallery_museum_custom_css .='.read-btn a.blogbutton-small, #comments input[type="submit"].submit{';
		$art_gallery_museum_custom_css .='border-radius: '.esc_attr($art_gallery_museum_button_border_radius).'px;';
	$art_gallery_museum_custom_css .='}';

	/*-------------- Woocommerce Button  -------------------*/

	$art_gallery_museum_woocommerce_button_padding_top = get_theme_mod('art_gallery_museum_woocommerce_button_padding_top');
	if($art_gallery_museum_woocommerce_button_padding_top != false){
		$art_gallery_museum_custom_css .='.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce button.button.alt, a.button.wc-forward, .woocommerce .cart .button, .woocommerce .cart input.button{';
			$art_gallery_museum_custom_css .='padding-top: '.esc_attr($art_gallery_museum_woocommerce_button_padding_top).'px; padding-bottom: '.esc_attr($art_gallery_museum_woocommerce_button_padding_top).'px;';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_woocommerce_button_padding_right = get_theme_mod('art_gallery_museum_woocommerce_button_padding_right');
	if($art_gallery_museum_woocommerce_button_padding_right != false){
		$art_gallery_museum_custom_css .='.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce button.button.alt, a.button.wc-forward, .woocommerce .cart .button, .woocommerce .cart input.button{';
			$art_gallery_museum_custom_css .='padding-left: '.esc_attr($art_gallery_museum_woocommerce_button_padding_right).'px; padding-right: '.esc_attr($art_gallery_museum_woocommerce_button_padding_right).'px;';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_woocommerce_button_border_radius = get_theme_mod('art_gallery_museum_woocommerce_button_border_radius');
	if($art_gallery_museum_woocommerce_button_border_radius != false){
		$art_gallery_museum_custom_css .='.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce button.button.alt, a.button.wc-forward, .woocommerce .cart .button, .woocommerce .cart input.button{';
			$art_gallery_museum_custom_css .='border-radius: '.esc_attr($art_gallery_museum_woocommerce_button_border_radius).'px;';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_related_product = get_theme_mod('art_gallery_museum_related_product',true);

	if($art_gallery_museum_related_product == false){
		$art_gallery_museum_custom_css .='.related.products{';
			$art_gallery_museum_custom_css .='display: none;';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_woocommerce_product_border = get_theme_mod('art_gallery_museum_woocommerce_product_border',true);

	if($art_gallery_museum_woocommerce_product_border == false){
		$art_gallery_museum_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
			$art_gallery_museum_custom_css .='border: none;';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_woocommerce_product_padding_top = get_theme_mod('art_gallery_museum_woocommerce_product_padding_top',10);
		$art_gallery_museum_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
			$art_gallery_museum_custom_css .='padding-top: '.esc_attr($art_gallery_museum_woocommerce_product_padding_top).'px; padding-bottom: '.esc_attr($art_gallery_museum_woocommerce_product_padding_top).'px;';
		$art_gallery_museum_custom_css .='}';

	$art_gallery_museum_woocommerce_product_padding_right = get_theme_mod('art_gallery_museum_woocommerce_product_padding_right',10);
		$art_gallery_museum_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
			$art_gallery_museum_custom_css .='padding-left: '.esc_attr($art_gallery_museum_woocommerce_product_padding_right).'px; padding-right: '.esc_attr($art_gallery_museum_woocommerce_product_padding_right).'px;';
		$art_gallery_museum_custom_css .='}';

	$art_gallery_museum_woocommerce_product_border_radius = get_theme_mod('art_gallery_museum_woocommerce_product_border_radius');
	if($art_gallery_museum_woocommerce_product_border_radius != false){
		$art_gallery_museum_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
			$art_gallery_museum_custom_css .='border-radius: '.esc_attr($art_gallery_museum_woocommerce_product_border_radius).'px;';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_woocommerce_product_box_shadow = get_theme_mod('art_gallery_museum_woocommerce_product_box_shadow');
	if($art_gallery_museum_woocommerce_product_box_shadow != false){
		$art_gallery_museum_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
			$art_gallery_museum_custom_css .='box-shadow: '.esc_attr($art_gallery_museum_woocommerce_product_box_shadow).'px '.esc_attr($art_gallery_museum_woocommerce_product_box_shadow).'px '.esc_attr($art_gallery_museum_woocommerce_product_box_shadow).'px #aaa;';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_product_sale_font_size = get_theme_mod('art_gallery_museum_product_sale_font_size');
	$art_gallery_museum_custom_css .='.woocommerce span.onsale {';
		$art_gallery_museum_custom_css .='font-size: '.esc_attr($art_gallery_museum_product_sale_font_size).'px;';
	$art_gallery_museum_custom_css .='}';

	/*---- Preloader Color ----*/
	$art_gallery_museum_preloader_color = get_theme_mod('art_gallery_museum_preloader_color');
	$art_gallery_museum_preloader_bg_color = get_theme_mod('art_gallery_museum_preloader_bg_color');

	if($art_gallery_museum_preloader_color != false){
		$art_gallery_museum_custom_css .='.preloader-squares .square, .preloader-chasing-squares .square{';
			$art_gallery_museum_custom_css .='background-color: '.esc_attr($art_gallery_museum_preloader_color).';';
		$art_gallery_museum_custom_css .='}';
	}
	if($art_gallery_museum_preloader_bg_color != false){
		$art_gallery_museum_custom_css .='.preloader{';
			$art_gallery_museum_custom_css .='background-color: '.esc_attr($art_gallery_museum_preloader_bg_color).';';
		$art_gallery_museum_custom_css .='}';
	}

	/*---- Copyright css ----*/
	$art_gallery_museum_copyright_fontsize = get_theme_mod('art_gallery_museum_copyright_fontsize',16);
	if($art_gallery_museum_copyright_fontsize != false){
		$art_gallery_museum_custom_css .='#footer p{';
			$art_gallery_museum_custom_css .='font-size: '.esc_attr($art_gallery_museum_copyright_fontsize).'px; ';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_copyright_top_bottom_padding = get_theme_mod('art_gallery_museum_copyright_top_bottom_padding',15);
	if($art_gallery_museum_copyright_top_bottom_padding != false){
		$art_gallery_museum_custom_css .='#footer {';
			$art_gallery_museum_custom_css .='padding-top:'.esc_attr($art_gallery_museum_copyright_top_bottom_padding).'px; padding-bottom: '.esc_attr($art_gallery_museum_copyright_top_bottom_padding).'px; ';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_copyright_alignment = get_theme_mod( 'art_gallery_museum_copyright_alignment','Center');
    if($art_gallery_museum_copyright_alignment == 'Left'){
		$art_gallery_museum_custom_css .='#footer p{';
			$art_gallery_museum_custom_css .='text-align:start;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_copyright_alignment == 'Center'){
		$art_gallery_museum_custom_css .='#footer p{';
			$art_gallery_museum_custom_css .='text-align:center;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_copyright_alignment == 'Right'){
		$art_gallery_museum_custom_css .='#footer p{';
			$art_gallery_museum_custom_css .='text-align:end;';
		$art_gallery_museum_custom_css .='}';
	}

	/*------- Wocommerce sale css -----*/
	$art_gallery_museum_woocommerce_sale_top_padding = get_theme_mod('art_gallery_museum_woocommerce_sale_top_padding');
	$art_gallery_museum_woocommerce_sale_left_padding = get_theme_mod('art_gallery_museum_woocommerce_sale_left_padding');
	$art_gallery_museum_custom_css .=' .woocommerce span.onsale{';
		$art_gallery_museum_custom_css .='padding-top: '.esc_attr($art_gallery_museum_woocommerce_sale_top_padding).'px; padding-bottom: '.esc_attr($art_gallery_museum_woocommerce_sale_top_padding).'px; padding-left: '.esc_attr($art_gallery_museum_woocommerce_sale_left_padding).'px; padding-right: '.esc_attr($art_gallery_museum_woocommerce_sale_left_padding).'px;';
	$art_gallery_museum_custom_css .='}';

	$art_gallery_museum_woocommerce_sale_border_radius = get_theme_mod('art_gallery_museum_woocommerce_sale_border_radius', 0);
	$art_gallery_museum_custom_css .='.woocommerce span.onsale{';
		$art_gallery_museum_custom_css .='border-radius: '.esc_attr($art_gallery_museum_woocommerce_sale_border_radius).'px;';
	$art_gallery_museum_custom_css .='}';

	$art_gallery_museum_sale_position = get_theme_mod( 'art_gallery_museum_sale_position','right');
    if($art_gallery_museum_sale_position == 'left'){
		$art_gallery_museum_custom_css .='.woocommerce ul.products li.product .onsale{';
			$art_gallery_museum_custom_css .='left: -10px; right: auto;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_sale_position == 'right'){
		$art_gallery_museum_custom_css .='.woocommerce ul.products li.product .onsale{';
			$art_gallery_museum_custom_css .='left: auto; right: 0;';
		$art_gallery_museum_custom_css .='}';
	}

	/*-------- footer background css -------*/
	$art_gallery_museum_footer_background_color = get_theme_mod('art_gallery_museum_footer_background_color');
	$art_gallery_museum_custom_css .='.footertown{';
		$art_gallery_museum_custom_css .='background-color: '.esc_attr($art_gallery_museum_footer_background_color).';';
	$art_gallery_museum_custom_css .='}';

	$art_gallery_museum_footer_background_img = get_theme_mod('art_gallery_museum_footer_background_img');
	if($art_gallery_museum_footer_background_img != false){
		$art_gallery_museum_custom_css .='.footertown{';
			$art_gallery_museum_custom_css .='background: url('.esc_attr($art_gallery_museum_footer_background_img).') no-repeat; background-size: cover; background-attachment: fixed;';
		$art_gallery_museum_custom_css .='}';
	}

	/*---- Comment form ----*/
	$art_gallery_museum_comment_width = get_theme_mod('art_gallery_museum_comment_width', '100');
	$art_gallery_museum_custom_css .='#comments textarea{';
		$art_gallery_museum_custom_css .=' width:'.esc_attr($art_gallery_museum_comment_width).'%;';
	$art_gallery_museum_custom_css .='}';

	$art_gallery_museum_comment_submit_text = get_theme_mod('art_gallery_museum_comment_submit_text', 'Post Comment');
	if($art_gallery_museum_comment_submit_text == ''){
		$art_gallery_museum_custom_css .='#comments p.form-submit {';
			$art_gallery_museum_custom_css .='display: none;';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_comment_title = get_theme_mod('art_gallery_museum_comment_title', 'Leave a Reply');
	if($art_gallery_museum_comment_title == ''){
		$art_gallery_museum_custom_css .='#comments h2#reply-title {';
			$art_gallery_museum_custom_css .='display: none;';
		$art_gallery_museum_custom_css .='}';
	}

	// Sticky Header padding
	$art_gallery_museum_sticky_header_padding = get_theme_mod('art_gallery_museum_sticky_header_padding');
	$art_gallery_museum_custom_css .='.fixed-header{';
		$art_gallery_museum_custom_css .=' padding-top:'.esc_attr($art_gallery_museum_sticky_header_padding).'px; padding-bottom:'.esc_attr($art_gallery_museum_sticky_header_padding).'px;';
	$art_gallery_museum_custom_css .='}';

	// Navigation Font Size 
	$art_gallery_museum_nav_font_size = get_theme_mod('art_gallery_museum_nav_font_size');
	if($art_gallery_museum_nav_font_size != false){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .='font-size: '.esc_attr($art_gallery_museum_nav_font_size).'px;';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_navigation_case = get_theme_mod('art_gallery_museum_navigation_case', 'uppercase');
	if($art_gallery_museum_navigation_case == 'uppercase' ){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .=' text-transform: uppercase;';
		$art_gallery_museum_custom_css .='}';
	}elseif($art_gallery_museum_navigation_case == 'capitalize' ){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .=' text-transform: capitalize;';
		$art_gallery_museum_custom_css .='}';
	}


	//Site title Font size
	$art_gallery_museum_site_title_fontsize = get_theme_mod('art_gallery_museum_site_title_fontsize');
	$art_gallery_museum_custom_css .='.logo h1, .logo p.site-title{';
		$art_gallery_museum_custom_css .='font-size: '.esc_attr($art_gallery_museum_site_title_fontsize).'px;';
	$art_gallery_museum_custom_css .='}';

	$art_gallery_museum_site_description_fontsize = get_theme_mod('art_gallery_museum_site_description_fontsize');
	$art_gallery_museum_custom_css .='.logo p.site-description{';
		$art_gallery_museum_custom_css .='font-size: '.esc_attr($art_gallery_museum_site_description_fontsize).'px;';
	$art_gallery_museum_custom_css .='}';

	/*----- Featured image css -----*/
	$art_gallery_museum_featured_image_border_radius = get_theme_mod('art_gallery_museum_featured_image_border_radius');
	if($art_gallery_museum_featured_image_border_radius != false){
		$art_gallery_museum_custom_css .='.inner-service .service-image img{';
			$art_gallery_museum_custom_css .='border-radius: '.esc_attr($art_gallery_museum_featured_image_border_radius).'px;';
		$art_gallery_museum_custom_css .='}';
	}

	$art_gallery_museum_featured_image_box_shadow = get_theme_mod('art_gallery_museum_featured_image_box_shadow');
	if($art_gallery_museum_featured_image_box_shadow != false){
		$art_gallery_museum_custom_css .='.inner-service .service-image img{';
			$art_gallery_museum_custom_css .='box-shadow: 8px 8px '.esc_attr($art_gallery_museum_featured_image_box_shadow).'px #aaa;';
		$art_gallery_museum_custom_css .='}';
	} 

	/*------Shop page pagination ---------*/
	$art_gallery_museum_shop_page_pagination = get_theme_mod('art_gallery_museum_shop_page_pagination', true);
	if($art_gallery_museum_shop_page_pagination == false){
		$art_gallery_museum_custom_css .= '.woocommerce nav.woocommerce-pagination {';
			$art_gallery_museum_custom_css .='display: none;';
		$art_gallery_museum_custom_css .='}';
	}

	/*------- Post into blocks ------*/
	$art_gallery_museum_post_blocks = get_theme_mod('art_gallery_museum_post_blocks', 'Without box');
	if($art_gallery_museum_post_blocks == 'Within box' ){
		$art_gallery_museum_custom_css .='.services-box{';
			$art_gallery_museum_custom_css .=' border: 1px solid #222;';
		$art_gallery_museum_custom_css .='}';
	}

	//  ------------ Mobile Media Options ----------
	$art_gallery_museum_responsive_show_back_to_top = get_theme_mod('art_gallery_museum_responsive_show_back_to_top',true);
	if($art_gallery_museum_responsive_show_back_to_top == true && get_theme_mod('art_gallery_museum_show_back_to_top',true) == false){
		$art_gallery_museum_custom_css .='@media screen and (min-width:575px){
			.scrollup{';
			$art_gallery_museum_custom_css .='visibility:hidden;';
		$art_gallery_museum_custom_css .='} }';
	}

	if($art_gallery_museum_responsive_show_back_to_top == false){
		$art_gallery_museum_custom_css .='@media screen and (max-width:575px){
			.scrollup{';
			$art_gallery_museum_custom_css .='visibility:hidden;';
		$art_gallery_museum_custom_css .='} }';
	}

	$art_gallery_museum_responsive_preloader_hide = get_theme_mod('art_gallery_museum_responsive_preloader_hide',false);
	if($art_gallery_museum_responsive_preloader_hide == true && get_theme_mod('art_gallery_museum_preloader_hide',false) == false){
		$art_gallery_museum_custom_css .='@media screen and (min-width:575px){
			.preloader{';
			$art_gallery_museum_custom_css .='display:none !important;';
		$art_gallery_museum_custom_css .='} }';
	}

	if($art_gallery_museum_responsive_preloader_hide == false){
		$art_gallery_museum_custom_css .='@media screen and (max-width:575px){
			.preloader{';
			$art_gallery_museum_custom_css .='display:none !important;';
		$art_gallery_museum_custom_css .='} }';
	}

	// menu font weight
	$art_gallery_museum_theme_lay = get_theme_mod( 'art_gallery_museum_font_weight_menu_option','600');
    if($art_gallery_museum_theme_lay == '100'){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .='font-weight:100;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_theme_lay == '200'){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .='font-weight: 200;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_theme_lay == '300'){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .='font-weight: 300;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_theme_lay == '400'){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .='font-weight: 400;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_theme_lay == '500'){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .='font-weight: 500;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_theme_lay == '600'){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .='font-weight: 600;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_theme_lay == '700'){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .='font-weight: 700;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_theme_lay == '800'){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .='font-weight: 800;';
		$art_gallery_museum_custom_css .='}';
	}else if($art_gallery_museum_theme_lay == '900'){
		$art_gallery_museum_custom_css .='.primary-navigation ul li a{';
			$art_gallery_museum_custom_css .='font-weight: 900;';
		$art_gallery_museum_custom_css .='}';
	}

	//slider
	$art_gallery_museum_slider_hide_show = get_theme_mod('art_gallery_museum_slider_hide_show',false);
	if($art_gallery_museum_slider_hide_show == false){
		$art_gallery_museum_custom_css .='.page-template-custom-frontpage .menu-section{';
			$art_gallery_museum_custom_css .=' position: static; background: #1c1d21;';
		$art_gallery_museum_custom_css .='}';
	}

	//Copyright background css
	$art_gallery_museum_copyright_background_color = get_theme_mod('art_gallery_museum_copyright_background_color');
	$art_gallery_museum_custom_css .='#footer{';
		$art_gallery_museum_custom_css .='background-color: '.esc_attr($art_gallery_museum_copyright_background_color).';';
	$art_gallery_museum_custom_css .='}';
     