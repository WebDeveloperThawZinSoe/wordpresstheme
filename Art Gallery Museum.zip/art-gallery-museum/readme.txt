=== Art Gallery Museum WordPress Theme ===
Contributors: ThemesCaliber
Tags: left-sidebar, right-sidebar, one-column, two-columns, grid-layout, block-styles, wide-blocks, custom-background, custom-logo, custom-menu, custom-header, editor-style, featured-images, footer-widgets, flexible-header, sticky-post, full-width-template, theme-options, threaded-comments, photography, portfolio, e-commerce
Requires at least: 5.0
Tested up to: 5.9
Requires PHP: 7.2
Stable tag: 0.1.3
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl.html

Art Gallery Museum is an attractive WordPress theme built for art galleries, art studios, statue and painting exhibitions, history and monumental libraries, museums, archaeological galleries, etc.

== Description ==

Art Gallery Museum is an attractive WordPress theme built for art galleries, art studios, statue and painting exhibitions, history and monumental libraries, museums, archaeological galleries, etc. This theme comes with a clean, attractive, and sophisticated display giving a beautiful layout for bringing the retina-ready pictures of the museum and art galleries online. It is created using the powerful Bootstrap framework and makes use of standard coding practices. Its mobile-friendly design is going to make your website get a stunning look on several devices and make it available for easy access through smartphones and tablets. Personalization options are made available in case you want to add a few twists to the existing design. This free theme is also made interactive to engage visitors and Call to Action Buttons (CTA) are also included that get reflected in better conversion rates. The codes are optimized and made SEO-friendly for delivering faster page load time and stunning performance across all the browsers and devices. The cleanly designed Team, Testimonial section, and other various theme elements give a positive impact at the first look itself. CSS animations are also added to bring more visual appeal. Social media options for better online promotion are added to the theme.

== Changelog ==

= 0.1 =
* Initial Version Released.

= 0.1.1 =
* Removed owl carousel from theme.
* Changed theme screenshot.

= 0.1.2 =
* Added footer link.
* Added getstarted in theme.

= 0.1.3 =
* Added Copyright Background Color.
* Added .pot file in theme.

== Resources ==

Art Gallery Museum WordPress Theme, Copyright 2022 ThemesCaliber
Art Gallery Museum is distributed under the terms of the GNU GPL

Theme is Built using the following resource bundles.

- Bootstrap 
	-- Mark Otto
	-- copyright 2011-2021, Mark Otto
	-- https://github.com/twbs/bootstrap/releases/download/v5.0.1/bootstrap-5.0.1-dist.zip
	-- License: Code released under the MIT License. v5.0.1
	-- https://github.com/twbs/bootstrap/blob/main/LICENSE

- Font-Awesome 
	-- Davegandy
	-- copyright July 12, 2018, Davegandy
	-- https://github.com/FortAwesome/Font-Awesome.git
	-- License: Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License
	-- https://github.com/FortAwesome/Font-Awesome/blob/master/LICENSE.txt

- Customizer Pro 
	-- Justin Tadlock
	-- Copyright 2016, Justin Tadlock
	-- https://github.com/justintadlock/trt-customizer-pro.git
	-- License: GNU General Public License v2.0
	-- http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

- Superfish 
	-- Joeldbirch
	-- Copyright 2013, Justin Tadlock
	-- https://github.com/joeldbirch/superfish.git
	-- License: Free to use and abuse under the MIT license. v1.7.9
	-- https://github.com/joeldbirch/superfish/blob/master/MIT-LICENSE.txt

- Pxhere Images
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pxhere.com/en/license

	Slider Image, 
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pxhere.com/en/photo/37365

	Venue Image, 
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pxhere.com/en/photo/446

	Venue Image, 
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pxhere.com/en/photo/559476

	Venue Image, 
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pxhere.com/en/photo/1414417