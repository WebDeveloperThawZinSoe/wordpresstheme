<a href="<?php echo "?page=yooslider-templates&type=".$gks_adminPageType; ?>">
  <div class="gks-btn gks-library-btn">
    <div class="gks-btn-content">
      <div class="gks-btn-icon gks-library-icon"></div>
      <h3 class="gks-btn-title">TEMPLATE LIBRARY</h3>
      <div class="gks-btn-overlay"></div>
      <!-- <div class='gks-templates-coming-badge'>COMING SOON</div> -->
    </div>
  </div>
</a>
