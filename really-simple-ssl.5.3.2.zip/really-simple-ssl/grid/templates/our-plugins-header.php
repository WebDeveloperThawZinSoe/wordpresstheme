<div class="rsssl-secondary-header-item">
    <a href="https://really-simple-plugins.com/">
        <img src="<?php echo rsssl_url?>assets/really-simple-plugins.png" alt="Really Simple Plugins Logo">
    </a>
</div>