<?php
namespace Nextend\SmartSlider3\Application\Admin\Layout\Block\Core\AdminEmpty;

use Nextend\SmartSlider3\Settings;

/**
 * @var $this BlockAdminEmpty
 */
?>
<div <?php $this->renderAttributes(); ?>>
    <?php $this->displayContent(); ?>
</div>