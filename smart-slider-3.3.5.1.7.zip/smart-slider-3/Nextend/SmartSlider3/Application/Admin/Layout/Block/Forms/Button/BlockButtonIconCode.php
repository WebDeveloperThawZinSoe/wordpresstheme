<?php


namespace Nextend\SmartSlider3\Application\Admin\Layout\Block\Forms\Button;


class BlockButtonIconCode extends BlockButtonIcon {

    protected function getContent() {

        return $this->icon;
    }
}