<?php

namespace CF\API\Exception;

abstract class CloudFlareException extends \Exception
{
}
